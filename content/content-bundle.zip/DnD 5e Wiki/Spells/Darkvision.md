### Darkvision

*2nd-level transmutation*

**Casting Time:** 1 action

**Range:** Touch

**Components:** V, S, M (either a pinch of dried carrot or an agate)

**Duration:** 8 hours

You touch a willing creature to grant it the ability to see in the dark. For the duration, that creature has darkvision out to a range of 60 feet.

#Spell
